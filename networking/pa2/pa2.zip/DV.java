package pa2;
import java.io.Serializable;

class DV implements Serializable{

    public int node_num=0;
    public int[] dv = new int[1];
    private static final long serialVersionUID = 1L;

//    public void init(int nodes){
//        dv = new int[nodes];
//    }

}